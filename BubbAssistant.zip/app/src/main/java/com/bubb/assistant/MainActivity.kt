package com.bubb.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.WindowInsets
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var radio: RadioGroup
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var urlEdit: EditText
    private lateinit var sizeLabel: TextView
    private lateinit var seek: SeekBar
    private lateinit var ttsCheck: CheckBox
    private lateinit var testResult: TextView
    private var currentId = "gemini"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFF3B2A4A.toInt())
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(2))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun edit(hint: String, secret: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT or
            (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        currentId = prefs.provider

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        root.addView(label("Bubb Assistant \uD83C\uDF38", 26f, true))
        root.addView(label("Asisten chibi yang melayang di atas aplikasi lain."))
        status = label("")
        root.addView(status)

        // --- langkah 1-3
        root.addView(label("Langkah awal", 18f, true))
        root.addView(button("1. Izinkan tampil di atas aplikasi lain") { grantOverlay() })
        root.addView(button("2. Izinkan notifikasi (untuk tombol sembunyikan/tutup)") { askNotif() })
        root.addView(button("3. \u25B6 Mulai / muat ulang Bubb") { startBubb() })
        root.addView(button("\u23F9 Hentikan Bubb") {
            stopService(Intent(this, FloatingService::class.java))
            toast("Bubb dihentikan.")
        })

        // --- AI
        root.addView(label("Pengaturan AI (gratis, kamu isi sendiri)", 18f, true))
        root.addView(label("Pilih layanan, ambil API key gratisnya, lalu tempel di sini. Key tersimpan hanya di HP-mu."))
        radio = RadioGroup(this)
        PRESETS.forEachIndexed { i, p ->
            radio.addView(RadioButton(this).apply { id = 1000 + i; text = p.label })
        }
        root.addView(radio)

        keyEdit = edit("API key", secret = true)
        modelEdit = edit("Nama model")
        urlEdit = edit("Base URL (untuk Groq/OpenRouter/Kustom)")
        root.addView(button("Buka halaman pembuatan API key") { openKeyPage() })
        root.addView(keyEdit)
        root.addView(modelEdit)
        root.addView(urlEdit)

        val idx = PRESETS.indexOfFirst { it.id == currentId }.let { if (it < 0) 0 else it }
        radio.check(1000 + idx)
        keyEdit.setText(prefs.keyFor(currentId))
        modelEdit.setText(prefs.model)
        urlEdit.setText(prefs.baseUrl)
        urlEdit.isEnabled = currentId != "gemini"

        radio.setOnCheckedChangeListener { _, checked ->
            val p = PRESETS.getOrNull(checked - 1000) ?: return@setOnCheckedChangeListener
            prefs.setKeyFor(currentId, keyEdit.text.toString().trim())
            currentId = p.id
            keyEdit.setText(prefs.keyFor(currentId))
            modelEdit.setText(p.model)
            urlEdit.setText(p.baseUrl)
            urlEdit.isEnabled = p.id != "gemini"
        }

        root.addView(button("Tes koneksi AI") { testAi() })
        testResult = label("")
        root.addView(testResult)

        // --- tampilan & suara
        root.addView(label("Tampilan & suara", 18f, true))
        sizeLabel = label("")
        root.addView(sizeLabel)
        seek = SeekBar(this).apply {
            max = 4
            progress = prefs.sizePct - 8
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { updateSizeLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(seek)
        updateSizeLabel()
        ttsCheck = CheckBox(this).apply {
            text = "Bubb membacakan jawaban (Text-to-Speech)"
            isChecked = prefs.ttsOn
        }
        root.addView(ttsCheck)
        root.addView(button("Simpan & terapkan") {
            saveSettings()
            if (Settings.canDrawOverlays(this)) startBubb() else toast("Tersimpan.")
        })

        root.addView(label("Cara pakai: ketuk Bubb untuk membuka chat, seret untuk memindahkan. Tombol \uD83D\uDE48 di chat menyembunyikan Bubb; munculkan lagi lewat notifikasi atau tombol Mulai."))
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    private fun updateSizeLabel() {
        sizeLabel.text = "Ukuran karakter: ${8 + seek.progress}% lebar layar"
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val key = prefs.isConfigured()
        status.text = (if (overlay) "\u2705" else "\u274C") + " Izin overlay\n" +
            (if (key) "\u2705" else "\u274C") + " AI sudah diatur"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun saveSettings() {
        val i = radio.checkedRadioButtonId - 1000
        val p = PRESETS.getOrNull(i) ?: return
        prefs.provider = p.id
        prefs.setKeyFor(p.id, keyEdit.text.toString().trim())
        prefs.model = modelEdit.text.toString().trim()
        prefs.baseUrl = urlEdit.text.toString().trim()
        prefs.ttsOn = ttsCheck.isChecked
        prefs.sizePct = 8 + seek.progress
    }

    private fun grantOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            toast("Izin notifikasi sudah aktif.")
        }
    }

    private fun startBubb() {
        saveSettings()
        if (!Settings.canDrawOverlays(this)) {
            toast("Beri izin overlay dulu (tombol 1).")
            grantOverlay()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_RELOAD))
        toast("Bubb dimulai! Buka aplikasi lain untuk melihatnya melayang.")
    }

    private fun openKeyPage() {
        val p = PRESETS.getOrNull(radio.checkedRadioButtonId - 1000) ?: return
        if (p.keyUrl.isEmpty()) { toast("Untuk layanan kustom, ambil key dari penyedia layananmu."); return }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.keyUrl)))
    }

    private fun testAi() {
        saveSettings()
        if (!prefs.isConfigured()) { toast("Isi API key dan nama model dulu."); return }
        testResult.text = "Menguji koneksi\u2026"
        Thread {
            val msg = try {
                "\u2705 Berhasil: " + AiClient(prefs).chat(
                    listOf(AiClient.Msg("user", "Sapa aku dalam satu kalimat pendek."))
                )
            } catch (e: Exception) {
                "\u274C Gagal: ${e.message}"
            }
            runOnUiThread { testResult.text = msg }
        }.start()
    }
}
