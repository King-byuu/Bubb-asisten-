package com.bubb.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

private class ChatLayout(ctx: Context, private val onBack: () -> Unit) : LinearLayout(ctx) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}

class FloatingService : Service() {

    companion object {
        const val ACTION_SHOW = "com.bubb.assistant.SHOW"
        const val ACTION_HIDE = "com.bubb.assistant.HIDE"
        const val ACTION_STOP = "com.bubb.assistant.STOP"
        const val ACTION_RELOAD = "com.bubb.assistant.RELOAD"
        private const val CHANNEL_ID = "bubb_channel"
        private const val NOTIF_ID = 1
        private val DARK = Color.parseColor("#3B2A4A")
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private var character: CharacterView? = null
    private var charParams: WindowManager.LayoutParams? = null

    private var chatView: View? = null
    private var chatShown = false
    private lateinit var messagesBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var ttsBtn: TextView

    private val history = mutableListOf<AiClient.Msg>()
    private var sending = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsWarned = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bubb Assistant", NotificationManager.IMPORTANCE_LOW)
        )
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.forLanguageTag("id-ID"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        when (intent?.action) {
            ACTION_HIDE -> hideOverlay()
            ACTION_STOP -> stopSelf()
            ACTION_RELOAD -> { closeChat(); removeCharacter(); showOverlay() }
            else -> showOverlay()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        closeChat()
        removeCharacter()
        tts?.stop(); tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }

    // ---------- notifikasi ----------

    private fun buildNotification(): Notification {
        val shown = character != null
        fun svc(action: String, req: Int) = PendingIntent.getService(
            this, req, Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 9, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_notification)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Bubb Assistant")
            .setContentText(if (shown) "Bubb sedang tampil" else "Bubb disembunyikan")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    icon, if (shown) "Sembunyikan" else "Tampilkan",
                    svc(if (shown) ACTION_HIDE else ACTION_SHOW, 1)
                ).build()
            )
            .addAction(Notification.Action.Builder(icon, "Tutup", svc(ACTION_STOP, 2)).build())
            .build()
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
    }

    // ---------- karakter overlay ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (character == null) {
            val dm = resources.displayMetrics
            val w = (dm.widthPixels * prefs.sizePct / 100f).toInt()
            val h = (w * 1.25f).toInt()
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = if (prefs.posX >= 0) prefs.posX else dm.widthPixels - w - dp(8)
            lp.y = if (prefs.posY >= 0) prefs.posY else (dm.heightPixels * 0.6f).toInt()
            clamp(lp)
            val cv = CharacterView(this)
            attachDrag(cv, lp)
            try {
                wm.addView(cv, lp)
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal menampilkan overlay: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
                return
            }
            character = cv
            charParams = lp
            cv.wave(2500L)
            cv.setExpression(Expression.HAPPY, 2500L)
        }
        updateNotification()
    }

    private fun removeCharacter() {
        character?.let {
            try { wm.removeView(it) } catch (e: Exception) { }
        }
        character = null
        charParams = null
    }

    private fun hideOverlay() {
        closeChat()
        removeCharacter()
        updateNotification()
    }

    private fun clamp(lp: WindowManager.LayoutParams) {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, max(0, dm.widthPixels - lp.width))
        lp.y = lp.y.coerceIn(0, max(0, dm.heightPixels - lp.height))
    }

    private fun attachDrag(v: View, lp: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        clamp(lp)
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { prefs.posX = lp.x; prefs.posY = lp.y } else toggleChat()
                    true
                }
                else -> false
            }
        }
    }

    private fun bringCharacterToFront() {
        val cv = character ?: return
        val lp = charParams ?: return
        try {
            wm.removeView(cv)
            wm.addView(cv, lp)
        } catch (e: Exception) { }
    }

    // ---------- jendela chat ----------

    private fun toggleChat() { if (chatShown) closeChat() else openChat() }

    private fun openChat() {
        if (chatShown) return
        if (chatView == null) chatView = buildChat()
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            (dm.widthPixels * 0.92f).toInt(), (dm.heightPixels * 0.40f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (dm.heightPixels * 0.07f).toInt()
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        try {
            wm.addView(chatView, lp)
            chatShown = true
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka chat: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        bringCharacterToFront()
        character?.wave(1800L)
        character?.setExpression(Expression.HAPPY, 2000L)
    }

    private fun closeChat() {
        if (chatShown) {
            try { wm.removeView(chatView) } catch (e: Exception) { }
            chatShown = false
        }
    }

    private fun headerBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setOnClickListener { onClick() }
    }

    private fun buildChat(): View {
        val pink = Color.parseColor("#F8A5C8")
        val root = ChatLayout(this) { closeChat() }
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable().apply {
            setColor(Color.parseColor("#F5FFF7FB"))
            cornerRadius = dp(20).toFloat()
            setStroke(dp(2), pink)
        }
        root.setPadding(dp(10), dp(8), dp(10), dp(10))

        // header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            TextView(this).apply {
                text = "Bubb \uD83C\uDF38"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(DARK)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        ttsBtn = headerBtn(if (prefs.ttsOn) "\uD83D\uDD0A" else "\uD83D\uDD07") {
            prefs.ttsOn = !prefs.ttsOn
            ttsBtn.text = if (prefs.ttsOn) "\uD83D\uDD0A" else "\uD83D\uDD07"
            if (!prefs.ttsOn) tts?.stop()
        }
        header.addView(ttsBtn)
        header.addView(headerBtn("\u2699") { openSettings() })
        header.addView(headerBtn("\uD83D\uDE48") { hideOverlay() })
        header.addView(headerBtn("\u2715") { closeChat() })
        root.addView(header)

        // daftar pesan
        scroll = ScrollView(this)
        messagesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(messagesBox)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // input
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Ketik pesan\u2026"
            textSize = 14f
            setTextColor(DARK)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), pink)
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val send = TextView(this).apply {
            text = "Kirim"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(DARK)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = GradientDrawable().apply { setColor(pink); cornerRadius = dp(16).toFloat() }
            setOnClickListener { sendMessage() }
        }
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.leftMargin = dp(6)
        row.addView(send, slp)
        root.addView(row)

        addNotice("Halo, aku Bubb! Ketik pesan untuk mengobrol. Jawaban datang dari layanan AI yang kamu atur di aplikasi.")
        return root
    }

    private fun openSettings() {
        closeChat()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun addBubble(text: String, user: Boolean): TextView {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(DARK)
            maxWidth = (resources.displayMetrics.widthPixels * 0.7f).toInt()
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(if (user) "#F8A5C8" else "#EFE6FA"))
                cornerRadius = dp(14).toFloat()
            }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.topMargin = dp(4)
        lp.bottomMargin = dp(2)
        messagesBox.addView(tv, lp)
        scrollDown()
        return tv
    }

    private fun addNotice(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTypeface(null, Typeface.ITALIC)
            setTextColor(Color.parseColor("#7A6A8A"))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        messagesBox.addView(
            tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        scrollDown()
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    // ---------- kirim pesan ke AI ----------

    private fun sendMessage() {
        if (sending) return
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        addBubble(text, true)

        if (!prefs.isConfigured()) {
            addNotice("AI belum diatur, jadi aku belum bisa menjawab. Ketuk \u2699 untuk memasukkan API key gratis (Gemini / Groq / OpenRouter).")
            character?.setExpression(Expression.SAD, 3500L)
            return
        }

        history.add(AiClient.Msg("user", text))
        val pending = addBubble("\u2026", false)
        sending = true
        character?.setExpression(Expression.SURPRISED, 1200L)
        val snapshot = history.takeLast(12).dropWhile { it.role != "user" }

        executor.execute {
            val result = runCatching { AiClient(prefs).chat(snapshot) }
            ui.post {
                sending = false
                result.onSuccess { reply ->
                    pending.text = reply
                    history.add(AiClient.Msg("assistant", reply))
                    if (history.size > 40) history.subList(0, history.size - 40).clear()
                    character?.wave(2000L)
                    character?.setExpression(Expression.HAPPY, 3000L)
                    speak(reply)
                }.onFailure { e ->
                    pending.text = "\u26A0 " + (e.message ?: "Terjadi kesalahan")
                    history.removeAt(history.lastIndex)
                    character?.setExpression(Expression.SAD, 4000L)
                }
                scrollDown()
            }
        }
    }

    // ---------- suara ----------

    private fun speak(text: String) {
        if (!prefs.ttsOn) return
        if (!ttsReady) {
            if (!ttsWarned) {
                ttsWarned = true
                addNotice("Suara bahasa Indonesia belum tersedia. Pasang data suara di Pengaturan > Teks ke ucapan.")
            }
            return
        }
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "bubb")
    }
}
