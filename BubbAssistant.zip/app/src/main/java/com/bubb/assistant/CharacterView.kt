package com.bubb.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

enum class Expression { NORMAL, HAPPY, SURPRISED, SAD }

private val SKIN = Color.parseColor("#FFE4D6")
private val HAIR = Color.parseColor("#F8A5C8")
private val HAIR_DARK = Color.parseColor("#EE8DB8")
private val EYE = Color.parseColor("#5B3A7A")
private val BLUSH = Color.argb(150, 255, 158, 181)
private val DRESS = Color.parseColor("#FFF8FC")
private val TRIM = Color.parseColor("#C9A7E8")
private val RIBBON = Color.parseColor("#FF6FA5")
private val RIBBON_DARK = Color.parseColor("#E0457F")
private val MOUTH = Color.parseColor("#D9506F")
private val TEAR = Color.parseColor("#8FD3FF")
private val SHADOW = Color.argb(40, 90, 58, 122)

/** Karakter chibi digambar dengan Canvas (tanpa file gambar). Ruang gambar 100 x 125. */
class CharacterView(context: Context) : View(context) {

    var expression: Expression = Expression.NORMAL
        private set

    private var blink = 1f
    private var waveUntil = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private val clock = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    private val resetRunnable = Runnable { expression = Expression.NORMAL; invalidate() }

    private val blinkLoop = object : Runnable {
        override fun run() {
            blinkOnce()
            handler.postDelayed(this, 2200L + rnd.nextInt(3300))
        }
    }

    private val idleLoop = object : Runnable {
        override fun run() {
            if (expression == Expression.NORMAL) {
                wave(2200L)
                setExpression(Expression.HAPPY, 2500L)
            }
            handler.postDelayed(this, 20000L + rnd.nextInt(15000))
        }
    }

    fun setExpression(e: Expression, resetAfterMs: Long = 0L) {
        handler.removeCallbacks(resetRunnable)
        expression = e
        invalidate()
        if (e != Expression.NORMAL && resetAfterMs > 0) handler.postDelayed(resetRunnable, resetAfterMs)
    }

    fun wave(durationMs: Long = 2200L) {
        waveUntil = SystemClock.uptimeMillis() + durationMs
        invalidate()
    }

    private fun blinkOnce() {
        ValueAnimator.ofFloat(1f, 0f, 1f).apply {
            duration = 180
            addUpdateListener { blink = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        clock.start()
        handler.postDelayed(blinkLoop, 1500)
        handler.postDelayed(idleLoop, 6000)
    }

    override fun onDetachedFromWindow() {
        clock.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    private fun fill(color: Int): Paint {
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.FILL; paint.color = color
        return paint
    }

    private fun stroke(color: Int, w: Float): Paint {
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE; paint.color = color
        paint.strokeWidth = w; paint.strokeCap = Paint.Cap.ROUND
        return paint
    }

    private fun oval(c: Canvas, l: Float, t: Float, r: Float, b: Float, p: Paint) {
        rect.set(l, t, r, b); c.drawOval(rect, p)
    }

    private fun rrect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, p: Paint) {
        rect.set(l, t, r, b); c.drawRoundRect(rect, rad, rad, p)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val s = width / 100f
        val now = SystemClock.uptimeMillis()
        val bob = sin(now / 2200.0 * 2.0 * PI).toFloat() * 2.5f // melayang naik-turun

        c.save()
        c.scale(s, s)

        // bayangan (tidak ikut naik-turun)
        val sw = 17f - bob * 0.9f
        oval(c, 50f - sw, 117f, 50f + sw, 122f, fill(SHADOW))

        c.translate(0f, bob)

        // rambut belakang + kuncir
        c.drawCircle(17f, 64f, 11f, fill(HAIR_DARK))
        c.drawCircle(83f, 64f, 11f, fill(HAIR_DARK))
        c.drawCircle(50f, 47f, 33f, fill(HAIR_DARK))

        // kaki & sepatu
        rrect(c, 41f, 100f, 47.5f, 112f, 3f, fill(SKIN))
        rrect(c, 52.5f, 100f, 59f, 112f, 3f, fill(SKIN))
        rrect(c, 39f, 110f, 49f, 116f, 3f, fill(TRIM))
        rrect(c, 51f, 110f, 61f, 116f, 3f, fill(TRIM))

        // gaun
        path.reset()
        path.moveTo(39f, 77f); path.lineTo(61f, 77f); path.lineTo(68f, 103f); path.lineTo(32f, 103f); path.close()
        c.drawPath(path, fill(DRESS))
        c.drawPath(path, stroke(TRIM, 1.2f))
        rrect(c, 32f, 99f, 68f, 103f, 2f, fill(HAIR))

        // lengan kiri (diam)
        c.save()
        c.rotate(14f, 38f, 81f)
        c.drawLine(38f, 81f, 38f, 96f, stroke(SKIN, 6f))
        c.restore()

        // lengan kanan (melambai)
        val waving = now < waveUntil
        val ang = if (waving) -(135f + sin(now / 110.0).toFloat() * 28f) else -14f
        c.save()
        c.rotate(ang, 62f, 81f)
        c.drawLine(62f, 81f, 62f, 96f, stroke(SKIN, 6f))
        c.restore()

        // kepala
        c.drawCircle(50f, 47f, 30f, fill(SKIN))

        // poni & rambut depan
        rect.set(19f, 16f, 81f, 78f)
        c.drawArc(rect, 180f, 180f, true, fill(HAIR))
        rrect(c, 19f, 44f, 26f, 64f, 3.5f, fill(HAIR))
        rrect(c, 74f, 44f, 81f, 64f, 3.5f, fill(HAIR))
        c.drawCircle(33f, 44f, 8f, fill(HAIR))
        c.drawCircle(50f, 45f, 8f, fill(HAIR))
        c.drawCircle(67f, 44f, 8f, fill(HAIR))

        // ahoge
        path.reset()
        path.moveTo(50f, 16f); path.quadTo(45f, 6f, 54f, 4f)
        c.drawPath(path, stroke(HAIR, 2.6f))

        // pita
        path.reset()
        path.moveTo(70f, 22f); path.lineTo(62f, 17f); path.lineTo(62f, 27f); path.close()
        path.moveTo(70f, 22f); path.lineTo(78f, 17f); path.lineTo(78f, 27f); path.close()
        c.drawPath(path, fill(RIBBON))
        c.drawCircle(70f, 22f, 2.2f, fill(RIBBON_DARK))

        // pipi merona
        oval(c, 25.5f, 64f, 36.5f, 70f, fill(BLUSH))
        oval(c, 63.5f, 64f, 74.5f, 70f, fill(BLUSH))

        drawEyes(c)
        drawMouth(c)

        c.restore()
    }

    private fun drawEyes(c: Canvas) {
        val cy = 59f
        for (ex in floatArrayOf(38f, 62f)) {
            when {
                expression == Expression.HAPPY -> {
                    rect.set(ex - 5.5f, cy - 5f, ex + 5.5f, cy + 5f)
                    c.drawArc(rect, 200f, 140f, false, stroke(EYE, 2.6f))
                }
                blink < 0.25f -> {
                    rect.set(ex - 5.5f, cy - 4f, ex + 5.5f, cy + 4f)
                    c.drawArc(rect, 20f, 140f, false, stroke(EYE, 2.4f))
                }
                else -> {
                    val big = expression == Expression.SURPRISED
                    val rx = if (big) 6.5f else 5.5f
                    val ry = (if (big) 8.5f else 7f) * max(blink, 0.15f)
                    oval(c, ex - rx, cy - ry, ex + rx, cy + ry, fill(EYE))
                    if (blink > 0.7f) {
                        c.drawCircle(ex - 1.8f, cy - ry * 0.35f, 2.1f, fill(Color.WHITE))
                        c.drawCircle(ex + 1.8f, cy + ry * 0.4f, 1f, fill(Color.WHITE))
                    }
                }
            }
        }
        if (expression == Expression.SAD) c.drawCircle(31f, 66f, 1.8f, fill(TEAR))
    }

    private fun drawMouth(c: Canvas) {
        when (expression) {
            Expression.NORMAL -> {
                rect.set(45.5f, 65.5f, 54.5f, 72f)
                c.drawArc(rect, 20f, 140f, false, stroke(MOUTH, 2f))
            }
            Expression.HAPPY -> {
                rect.set(45f, 66f, 55f, 75f)
                c.drawArc(rect, 0f, 180f, true, fill(MOUTH))
            }
            Expression.SURPRISED -> oval(c, 47.5f, 67f, 52.5f, 74f, fill(MOUTH))
            Expression.SAD -> {
                rect.set(45.5f, 69f, 54.5f, 75.5f)
                c.drawArc(rect, 200f, 140f, false, stroke(MOUTH, 2f))
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 1.25f).toInt())
    }
}
