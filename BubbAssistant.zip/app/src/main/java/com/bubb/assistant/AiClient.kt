package com.bubb.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Klien AI sungguhan (bukan jawaban palsu). Mendukung:
 *  - Google Gemini (REST generateContent)
 *  - Layanan kompatibel OpenAI (Groq, OpenRouter, dll.)
 * API key diambil dari pengaturan pengguna, tidak ada di kode.
 */
class AiClient(private val p: Prefs) {

    data class Msg(val role: String, val text: String) // role: "user" / "assistant"

    companion object {
        private const val SYSTEM =
            "Kamu adalah Bubb, asisten chibi yang imut, ramah, dan membantu. " +
            "Jawab singkat (maksimal 3-4 kalimat) dalam bahasa Indonesia kecuali pengguna memakai bahasa lain. " +
            "Jika tidak tahu, katakan terus terang."
    }

    @Throws(IOException::class)
    fun chat(history: List<Msg>): String {
        try {
            return if (p.provider == "gemini") gemini(history) else openAi(history)
        } catch (e: UnknownHostException) {
            throw IOException("Tidak ada koneksi internet.")
        } catch (e: SocketTimeoutException) {
            throw IOException("Koneksi habis waktu. Coba lagi.")
        }
    }

    private fun gemini(history: List<Msg>): String {
        val contents = JSONArray()
        for (m in history) {
            contents.put(
                JSONObject()
                    .put("role", if (m.role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${p.model.trim()}:generateContent"
        val res = JSONObject(post(url, mapOf("x-goog-api-key" to p.apiKey.trim()), body.toString()))
        val parts = res.optJSONArray("candidates")
            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IOException("AI tidak mengembalikan jawaban (mungkin diblokir filter keamanan).")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        val out = sb.toString().trim()
        if (out.isEmpty()) throw IOException("Jawaban AI kosong.")
        return out
    }

    private fun openAi(history: List<Msg>): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", SYSTEM))
        for (m in history) {
            messages.put(JSONObject().put("role", if (m.role == "user") "user" else "assistant").put("content", m.text))
        }
        val body = JSONObject().put("model", p.model.trim()).put("messages", messages)
        val url = p.baseUrl.trim().trimEnd('/') + "/chat/completions"
        val res = JSONObject(post(url, mapOf("Authorization" to "Bearer ${p.apiKey.trim()}"), body.toString()))
        val out = res.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?.optString("content", "")?.trim().orEmpty()
        if (out.isEmpty()) throw IOException("Jawaban AI kosong.")
        return out
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                throw IOException(
                    when (code) {
                        400 -> "Permintaan ditolak (400). Cek nama model & API key. ${text.take(160)}"
                        401, 403 -> "API key ditolak ($code). Periksa kembali key kamu."
                        404 -> "Model atau URL tidak ditemukan (404). Cek nama model."
                        429 -> "Kuota gratis habis atau terlalu cepat (429). Coba lagi nanti."
                        else -> "Server error $code. ${text.take(160)}"
                    }
                )
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
