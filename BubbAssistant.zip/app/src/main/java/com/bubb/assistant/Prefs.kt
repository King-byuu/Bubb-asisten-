package com.bubb.assistant

import android.content.Context

data class Preset(
    val id: String,
    val label: String,
    val baseUrl: String,
    val model: String,
    val keyUrl: String
)

val PRESETS = listOf(
    Preset("gemini", "Google Gemini (ada kuota gratis)", "", "gemini-2.5-flash", "https://aistudio.google.com/apikey"),
    Preset("groq", "Groq (ada kuota gratis)", "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "https://console.groq.com/keys"),
    Preset("openrouter", "OpenRouter (model berlabel :free)", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/keys"),
    Preset("custom", "Kustom (API kompatibel OpenAI)", "", "", "")
)

/**
 * Pengaturan disimpan di penyimpanan PRIBADI aplikasi (bukan di dalam kode/APK).
 * API key diketik sendiri oleh pengguna di dalam aplikasi.
 */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("bubb_prefs", Context.MODE_PRIVATE)

    var provider: String
        get() = sp.getString("provider", "gemini") ?: "gemini"
        set(v) { sp.edit().putString("provider", v).apply() }

    fun keyFor(id: String): String = sp.getString("key_$id", "") ?: ""
    fun setKeyFor(id: String, v: String) { sp.edit().putString("key_$id", v).apply() }

    val apiKey: String get() = keyFor(provider)

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: ""
        set(v) { sp.edit().putString("model", v).apply() }

    var baseUrl: String
        get() = sp.getString("base_url", "") ?: ""
        set(v) { sp.edit().putString("base_url", v).apply() }

    var ttsOn: Boolean
        get() = sp.getBoolean("tts_on", true)
        set(v) { sp.edit().putBoolean("tts_on", v).apply() }

    /** Ukuran karakter dalam persen lebar layar (8..12). */
    var sizePct: Int
        get() = sp.getInt("size_pct", 11).coerceIn(8, 12)
        set(v) { sp.edit().putInt("size_pct", v.coerceIn(8, 12)).apply() }

    var posX: Int
        get() = sp.getInt("pos_x", -1)
        set(v) { sp.edit().putInt("pos_x", v).apply() }

    var posY: Int
        get() = sp.getInt("pos_y", -1)
        set(v) { sp.edit().putInt("pos_y", v).apply() }

    fun isConfigured(): Boolean =
        apiKey.isNotBlank() && model.isNotBlank() && (provider == "gemini" || baseUrl.isNotBlank())
}
